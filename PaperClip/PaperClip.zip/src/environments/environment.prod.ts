export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyDysj2cDOLlAw1E2w2sPvbnqtbK1kBeeUo",
    authDomain: "paper-clip-2d29f.firebaseapp.com",
    databaseURL: "https://paper-clip-2d29f.firebaseio.com",
    projectId: "paper-clip-2d29f",
    storageBucket: "",
    messagingSenderId: "261030326726"
  },
  registryToken: '6131549a-a5f6-4bdc-80d6-cd3fcab88b02'
};
